import json
import os

DATA_FILE = "data/lokasi.json"

def save_location(name, latitude, longitude):
    data = {}
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            data = json.load(f)
    data[name] = {"latitude": latitude, "longitude": longitude}
    with open(DATA_FILE, "w") as f:
        json.dump(data, f)
