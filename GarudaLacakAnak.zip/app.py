import streamlit as st

st.set_page_config(page_title="GarudaLacakAnak", layout="wide")

st.title("📍 GarudaLacakAnak")
st.markdown("Selamat datang di aplikasi pelacakan anak berbasis lokasi. Gunakan menu di samping untuk login sebagai anak atau orang tua.")
