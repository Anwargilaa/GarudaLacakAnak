import streamlit as st
from utils import save_location
from streamlit_javascript import st_javascript

st.header("🧒 Kirim Lokasi Saya")

name = st.text_input("Nama Anak / Kode", key="nama")
if name:
    js = st_javascript("""navigator.geolocation.getCurrentPosition(
        (loc) => {
            const coords = loc.coords;
            window.parent.postMessage({latitude: coords.latitude, longitude: coords.longitude}, "*");
        },
        (err) => {
            console.log(err);
        }
    );""")

    if isinstance(js, dict) and "latitude" in js:
        lat, lon = js["latitude"], js["longitude"]
        save_location(name, lat, lon)
        st.success(f"Lokasi berhasil dikirim: {lat}, {lon}")
