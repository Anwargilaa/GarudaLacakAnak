import streamlit as st
import json
from streamlit_folium import folium_static
import folium
import os

st.header("👨‍👩‍👧 Lihat Lokasi Anak")

data_path = "data/lokasi.json"
if os.path.exists(data_path):
    with open(data_path, "r") as f:
        lokasi_data = json.load(f)

    for anak, loc in lokasi_data.items():
        st.subheader(f"📍 {anak}")
        lat, lon = loc["latitude"], loc["longitude"]
        st.write(f"Lokasi: {lat}, {lon}")

        m = folium.Map(location=[lat, lon], zoom_start=16)
        folium.Marker([lat, lon], tooltip=anak).add_to(m)
        folium_static(m)
else:
    st.info("Belum ada data lokasi anak.")
